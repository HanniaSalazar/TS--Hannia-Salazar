﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L11_HFSM1123021
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int n = 0;
            int[] N;

            //ACTIVIDAD NO 1
            Console.WriteLine("ACTIVIDAD No.1");

            Console.WriteLine("");

            Console.WriteLine("Ingrese la cantidad de números que desea ingresar");
            n= Convert.ToInt32(Console.ReadLine());

            N= new int[n];

            for (int i = 0; i < N.Length; i++)
            {
                Console.WriteLine("Ingrese un número: ");
                N[i] = Convert.ToInt32(Console.ReadLine());
            }

            for (int i = 0; i < N.Length; i++)
            {
                Console.WriteLine("El número en posición " + i + " es "+ N[i]);
            }
            Console.WriteLine("");

            //ACTIVIDAD NO.2
            int sumatoria = 0;

            Console.WriteLine("ACTIVIDAD No.2");

            for (int i = 0; i < N.Length; i++)
            {
                sumatoria+= N[i];
            }
            Console.WriteLine("El resultado de la sumatoria es " + sumatoria);

            Console.WriteLine("");
            //ACTIVIDAD NO.3
            Console.WriteLine("ACTIVIDAD No.3");
            Console.WriteLine("El longitud de su arreglo es de " + N.Length);

            Console.WriteLine("");
            //ACTIVIDAD NO.4
            int suma=0;
            int suma1 = 0;
            Console.WriteLine("ACTIVIDAD No.4");
            for (int i = 0; i < N.Length; i++)
            {
                if (N[i] %2 ==0)
                {
                    suma= suma+N[i];
                }
                else
                {
                    suma1= suma1 +N[i];
                }
            }

            Console.WriteLine("La suma de los números pares es: "+ suma);
            Console.WriteLine("La suma de los números impares es: " + suma1);

            Console.ReadKey();

        }
    }
}
