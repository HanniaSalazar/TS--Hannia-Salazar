﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_HFSM1123021
{
    internal class Triangulo_Rectangulo
    {
        double catetoA;
        double anguloOpuestoA;
        double catetoB;
        double anguloOpuestoB;


        public Triangulo_Rectangulo(double cat, double ang)
        {
            catetoA = cat;
            anguloOpuestoA = ang;
        }


            public double ObtenerCatetoA()
            {
                return catetoA;
            }
             public double ObtenerCatetoB()
            {
                catetoB = catetoA/ Math.Atan(anguloOpuestoA);
                return catetoB;
            }

            public double ObtenerHipotenusa()
            {
                double hipotenusa = Math.Sqrt(Math.Pow(catetoA,2)+ Math.Pow(catetoB,2));
                return hipotenusa;
            }
            public double ObtenerAnguloOpuestoA()
            {
                return anguloOpuestoA;
            }
            public double ObtenerAnguloOpuestoB()
            {
            anguloOpuestoB = 90 - anguloOpuestoA;
                return anguloOpuestoB;
            }
            public double ObtenerArea()
            {
                double area = (catetoA*catetoB)/2;
                return area;
            }












    }

    }

