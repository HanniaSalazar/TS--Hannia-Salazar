﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab10_HFSM1123021
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double radio= Convert.ToDouble(textBox1.Text);

            Circulo objCirculo = new Circulo(radio);

            double perimetro, area, volumen;



            perimetro = objCirculo.ObtenerPerimetro();
            area = objCirculo.ObtenerArea();
            volumen= objCirculo.ObtenerVolumen();

            label2.Text = "El perímetro es: " + perimetro;
            label3.Text = "El área es: " + area;
            label4.Text = "El volumen es: " + volumen;

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            double catetoA1 = Convert.ToDouble(textBox2.Text);
            double anguloOpuestoA1 = Convert.ToDouble(textBox3.Text);

            Triangulo_Rectangulo objTriangulo = new Triangulo_Rectangulo(catetoA1,anguloOpuestoA1);

            double catetoB,hipotenusa, anguloB,area;
           
            catetoA1 = objTriangulo.ObtenerCatetoA();
            catetoB = objTriangulo.ObtenerCatetoB();
            hipotenusa = objTriangulo.ObtenerHipotenusa();
            anguloOpuestoA1 = objTriangulo.ObtenerAnguloOpuestoA();
            anguloB = objTriangulo.ObtenerAnguloOpuestoB();
            area = objTriangulo.ObtenerArea();

            label7.Text = "El cateto A es: " + catetoA1;
            label8.Text = "El cateto B es: " + catetoB;
            label9.Text = "La hipotenusa es: " + hipotenusa;
            label10.Text = "El valor del ángulo opuesto de A es: " + anguloOpuestoA1;
            label11.Text = "El valor del ángulo opuesto de B es: " + anguloB;
            label12.Text = "El área es: " + area;
        }
    }
}
