﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_HFSM1123021
{
    internal class Circulo
    {
        double radio;

        public Circulo(double rad)
        {
            radio = rad;

        }

        public double ObtenerPerimetro ()
        {
            double perimetro = 2 * Math.PI * radio;
            return perimetro;   
        }

        public double ObtenerArea()
        {
            double area = Math.PI * Math.Pow(radio,2) ;
            return area;
        }
        public double ObtenerVolumen()
        {
            double volumen = (4* Math.PI * Math.Pow(radio, 3))/ 3;
            return volumen;
        }

    }
}
