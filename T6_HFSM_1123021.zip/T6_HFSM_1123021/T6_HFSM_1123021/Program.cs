﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T6_HFSM_1123021
{
    internal class Program
    {
        static void Main(string[] args)
        
        {
            try
            {
                Console.WriteLine("Tarea");
                Console.ReadLine();
                Console.Clear();

                Console.WriteLine("¿Cuál es el año de su nacimiento?");
                int año = Int32.Parse(Console.ReadLine());

                Console.WriteLine("¿Cuál es el mes de su nacimiento?");
                int mes = Int32.Parse(Console.ReadLine());

                Console.WriteLine("¿Cuál es el día de su nacimiento?");
                int dia = Int32.Parse(Console.ReadLine());

                if(año < 1)
                {
                    Console.WriteLine("Ingrese un número mayor a 0");
                }
                else if(mes < 1)
                {
                    Console.WriteLine("Ingrese un número mayor a 0");
                }
                else
                {
                    switch (mes)
                    {
                        case 1:
                            if ((dia >= 1) && (dia <= 19))
                            {
                                Console.WriteLine("Signo Zodiacal: Capricornio");

                            }
                            else
                                 if ((dia >= 20) && (dia <= 31))
                            {
                                Console.WriteLine("Signo Zodiacal: Acuario");
                            }
                            else
                            {
                                Console.WriteLine("Ingrese un día válido");
                            }
                            break;

                        case 2:
                            if ((dia >= 1) && (dia <= 18))
                            {
                                Console.WriteLine("Signo Zodiacal: Acuario");

                            }
                            else
                                 if ((dia >= 19) && (dia <= 28))
                            {
                                Console.WriteLine("Signo Zodiacal: Piscis");
                            }
                            else
                            {
                                Console.WriteLine("Ingrese un día válido");
                            }
                            break;

                        case 3:
                            if ((dia >= 1) && (dia <= 20))
                            {
                                Console.WriteLine("Signo Zodiacal: Piscis");

                            }
                            else
                                 if ((dia >= 21) && (dia <= 31))
                            {
                                Console.WriteLine("Signo Zodiacal: Aries");
                            }
                            else
                            {
                                Console.WriteLine("Ingrese un día válido");
                            }
                            break;

                        case 4:
                            if ((dia >= 1) && (dia <= 19))
                            {
                                Console.WriteLine("Signo Zodiacal: Aries");

                            }
                            else
                         if ((dia >= 20) && (dia <= 30))
                            {
                                Console.WriteLine("Signo Zodiacal: Tauro");
                            }
                            else
                            {
                                Console.WriteLine("Ingrese un día válido");
                            }
                            break;

                        case 5:
                            if ((dia >= 1) && (dia <= 20))
                            {
                                Console.WriteLine("Signo Zodiacal: Tauro");

                            }
                            else
                         if ((dia >= 21) && (dia <= 31))
                            {
                                Console.WriteLine("Signo Zodiacal: Géminis");
                            }
                            else
                            {
                                Console.WriteLine("Ingrese un día válido");
                            }
                            break;

                        case 6:
                            if ((dia >= 1) && (dia <= 20))
                            {
                                Console.WriteLine("Signo Zodiacal: Géminis");

                            }
                            else
                        if ((dia >= 21) && (dia <= 30))
                            {
                                Console.WriteLine("Signo Zodiacal: Cáncer");
                            }
                            else
                            {
                                Console.WriteLine("Ingrese un día válido");
                            }
                            break;

                        case 7:
                            if ((dia >= 1) && (dia <= 22))
                            {
                                Console.WriteLine("Signo Zodiacal: Cáncer");

                            }
                            else
                       if ((dia >= 23) && (dia <= 31))
                            {
                                Console.WriteLine("Signo Zodiacal: Leo");
                            }
                            else
                            {
                                Console.WriteLine("Ingrese un día válido");
                            }
                            break;

                        case 8:
                            if ((dia >= 1) && (dia <= 22))
                            {
                                Console.WriteLine("Signo Zodiacal: Leo");

                            }
                            else
                     if ((dia >= 23) && (dia <= 31))
                            {
                                Console.WriteLine("Signo Zodiacal: Virgo");
                            }
                            else
                            {
                                Console.WriteLine("Ingrese un día válido");
                            }
                            break;

                        case 9:
                            if ((dia >= 1) && (dia <= 22))
                            {
                                Console.WriteLine("Signo Zodiacal: Virgo");

                            }
                            else
                     if ((dia >= 23) && (dia <= 30))
                            {
                                Console.WriteLine("Signo Zodiacal: Libra");
                            }
                            else
                            {
                                Console.WriteLine("Ingrese un día válido");
                            }
                            break;

                        case 10:
                            if ((dia >= 1) && (dia <= 22))
                            {
                                Console.WriteLine("Signo Zodiacal: Libra");

                            }
                            else
                    if ((dia >= 23) && (dia <= 31))
                            {
                                Console.WriteLine("Signo Zodiacal: Escorpio");
                            }
                            else
                            {
                                Console.WriteLine("Ingrese un día válido");
                            }
                            break;

                        case 11:
                            if ((dia >= 1) && (dia <= 21))
                            {
                                Console.WriteLine("Signo Zodiacal: Escorpio");

                            }
                            else
                     if ((dia >= 22) && (dia <= 30))
                            {
                                Console.WriteLine("Signo Zodiacal: Sagitario");
                            }
                            else
                            {
                                Console.WriteLine("Ingrese un día válido");
                            }
                            break;

                        case 12:
                            if ((dia >= 1) && (dia <= 21))
                            {
                                Console.WriteLine("Signo Zodiacal: Sagitario");

                            }
                            else

                             if ((dia >= 22) && (dia <= 31))
                            {
                                Console.WriteLine("Signo Zodiacal: Capricornio");
                            }
                            else
                            {
                                Console.WriteLine("Ingrese un día válido");
                            }
                            break;

                        default:
                            Console.WriteLine("Error");
                            break;
                    }
                }
            }
            catch
            {
                Console.WriteLine("Debe ingresar un número");
            }
            Console.ReadKey();
        }
     }
}

