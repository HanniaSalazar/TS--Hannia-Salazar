﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L13_HFSM1123021
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string opcion = "";

            int[,] tabla1 = new int[10, 15];
            int[,] tabla2 = new int[10, 10];
            //
            Random r = new Random();
            //
            int i = 0;
            int j = 0;
            double sumatoria1 = 0;
            double numero=1;
            double resultado = 0;
            


            Console.WriteLine("Menú Principal");
            Console.WriteLine("Seleccione la opción a la que desea ingresar: " + "(a,b,c)");
            Console.WriteLine("a. Llenar Matriz ");
            Console.WriteLine("b. Sumatoria ");
            Console.WriteLine("c. Mostrar Tablas de Multiplicar ");
            opcion = Console.ReadLine();

            Console.Clear();

            switch (opcion)
            {
                case "a":
                    Console.WriteLine("a. Llenar Matriz ");
                    for (i = 0; i < 10; i++)
                    {
                        for (j = 0; j < 15; j++)
                        {
                            tabla1[i, j] = r.Next(0, 150);
                        }
                    }

                    for (i = 0; i < 10; i++)
                    {
                        for (j = 0; j < 15; j++)
                        {
                            Console.Write(" " + tabla1[i, j]);

                        }
                        Console.WriteLine();
                    }
                    Console.ReadKey();

                    break;

                case "b":
                    Console.WriteLine("b. Sumatoria");
                    for (i = 0; i < 10; i++)
                    {
                        for (j = 0; j < 15; j++)
                        {
                            tabla1[i, j] = r.Next(0, 150);
                        }
                    }

                    for (i = 0; i < 10; i++)
                    {
                        for (j = 0; j < 15; j++)
                        {
                            Console.Write(" " + tabla1[i, j]);

                        }
                        Console.WriteLine();
                    }
                    for (i = 0; i < 10; i++)
                    {
                        for (j = 0; j < 15; j++)
                        {
                            sumatoria1 = sumatoria1 + tabla1[i, j];
                        }
                    }
                    Console.WriteLine("");
                    Console.WriteLine("La sumatoria de la tabla no.1 es: " + sumatoria1);
                    Console.ReadKey();
                    break;

                case "c":
                    Console.WriteLine("c. Mostrar Tablas de Multiplicar");

                    for (i = 0; i <10; i++)
                    {
                        for (j = 0; j < 10; j++)
                        {
                            tabla2[i, j] = (i + 1) * (j + 1);
                        }
                    }
                    for (i = 0; i < 10; i++)
                    {
                        for (j = 0; j <10; j++)
                        {
                            Console.Write(" " + tabla2[i, j]+ " ");
                        }
                        Console.WriteLine(" ");
                    }
                    Console.ReadKey();
                    break;

                default:
                    Console.WriteLine("Ninguna");
                    break;
            }
        }
    }
}
